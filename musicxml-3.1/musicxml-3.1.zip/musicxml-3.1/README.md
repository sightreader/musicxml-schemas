This repository maintained by the [W3C Music Notation Community Group](https://www.w3.org/community/music-notation/), and holds the latest release of the MusicXML specification. Please consult that page for further details. The group is chaired by Michael Good, Joe Berkovitz, and Daniel Spreadbury. 

To view (HTML) files not as sources but properly rendered in the browser, please use the [separate github view](http://w3c.github.io/musicxml/).
